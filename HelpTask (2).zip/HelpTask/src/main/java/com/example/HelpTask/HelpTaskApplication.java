package com.example.HelpTask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelpTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelpTaskApplication.class, args);
	}

}
