package com.example.HelpTask.Repositorio;

import com.example.HelpTask.api.Model.UsuarioModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.ResponseEntity;

public interface UsuarioRepositorio extends CrudRepository <UsuarioRepositorio, Integer>{
    ResponseEntity findById(String codigo);

    UsuarioModel save();
}
